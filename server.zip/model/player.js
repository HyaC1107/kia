const mongoose = require("mongoose");

const playerSchema = new mongoose.Schema({    
    backnum: String, 
    birth: Date,
    career: String,
    entry: Number,
    height: String,
    hittype: String,
    indate: Date,
    mainCareer: String,
    money: String,
    pcode: String,
    playerImg: String,
    playerName: String,
    playerProfileImg: String,
    position: String,
    promise: String,
    weight: String
});

module.exports = mongoose.model("Player",playerSchema);