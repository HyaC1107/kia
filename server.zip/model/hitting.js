const mongoose = require("mongoose");

const hittingSchema = new mongoose.Schema({    
    pcode: String,
    ab: Number,
    bb: Number,
    displayDate: Date,
    gd: Number,
    h2: Number,
    h3: Number,
    hit: Number,
    hr: Number,
    hra: String,
    kk: Number,
    matchTeamName: String,
    pa: Number,
    rbi: Number,
    run: Number,
    sb: Number,
    stadium: String
});

module.exports = mongoose.model("Hitting",hittingSchema);