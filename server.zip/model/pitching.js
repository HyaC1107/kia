const mongoose = require("mongoose");

const pitchingSchema = new mongoose.Schema({    
    pcode: String,
    ab: Number,
    bb: Number,
    displayDate: Date,
    er: Number,
    era: String,
    hit: Number,
    hp: Number,
    hr: Number,
    oc: Number,
    innDisplay: String,
    kk: Number,
    matchTeamName: String,
    pa: Number,
    r: Number,
    stadium: String,
    tugucount: Number,
    wls: String
});

module.exports = mongoose.model("Pitching",pitchingSchema);