const {Router} = require("express");
const support =require("../model/support");

const router = Router();

router.use((req,resp,next)=>{
    next();
});

router.get("/", async(req,resp)=>{
    try{
        const found = await support.find({}).lean();                
        return resp.status(200).json({result:true, datas:found });        
    }catch(e){
        console.log(e.message);
        return resp.status(500).json({result:false});
    }
    
});

router.post("/",async(req,resp)=>{
    try{
        return resp.status(200).json({result:true, datas:found });        
    }catch(e){
        console.log(e.message);
        return resp.status(500).json({result:false});
    }
});

module.exports = router;