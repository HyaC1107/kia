const {Router} = require("express");
const player = require("../model/player");

const router = Router();

router.use((req,resp,next)=>{
    
    next();
});

router.get("/list", async(req,resp)=>{
    const query = req.query;
    try{    
        const found = await player.find({}).select('-_id backnum pcode playerImg playerName position').lean(); 
        return resp.status(200).json({result:true, datas:found }); 
    }catch(e){
        console.log(e.message);
        return resp.status(500).json({result:false});
    }
    
});

router.get("/detail",async(req,resp)=>{
    const query = req.query;
    console.log(query);
    try{
        const found = await player.find({pcode:query.pcode}).select('-_id').lean();
        console.log(found);
        return resp.status(200).json({result:true, datas:found });        
    }catch(e){
        console.log(e.message);
        return resp.status(500).json({result:false});
    }
});

module.exports = router;