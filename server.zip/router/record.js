const {Router} = require("express");
const pitching = require("../model/pitching");
const hitting = require("../model/hitting");

const router = Router();

router.use((req,resp,next)=>{
    next();
});
router.get("/pitching",async(req,resp)=>{
    const query = req.query;
    try{
        const found = await pitching.find({pcode:query.pcode}).lean();
        let [w,l,sv,kk,innDisplay,er] = [0,0,0,0,0,0];
        for(i=0;i<found.length;i++) {
            switch(found[i].wls){
                case "W" : w++; // 승
                break;
                case "L": l++;  // 패
                break;
                case "S": sv++; // 세이브
                break;
            }
            kk += found[i].kk;  // 삼진
            er += found[i].er;    // 총 자책점
            innDisplay += found[i].oc/3  // 총 이닝수 
        };
        era = (er*9/innDisplay).toFixed(2);
        const sum = {era,kk,l,sv,w}
        console.log(sum);

        return resp.status(200).json({result:true, summary:sum, datas:found });        
    }catch(e){
        console.log(e.message);
        return resp.status(500).json({result:false});
    }
});


router.get("/hitting", async(req,resp)=>{
    const query = req.query;
    try{
        const found = await hitting.find({pcode:query.pcode}).lean();
        let [gamenum, hit, hr, rbi,ab, hra] = [0,0,0,0,0,0];
        for(i=0;i<found.length;i++) {
            hit += found[i].hit;   // 안타
            hr += found[i].hr;     // 홈런
            rbi += found[i].rbi;   // 타점
            ab += found[i].ab;     // 타수    
        };        
        gamenum = found.length;    // 게임수
        hra = (hit/ab).toFixed(3);  // 타율
        const sum = {gamenum,hit,hr,rbi,hra}

        return resp.status(200).json({result:true, summary:sum, datas:found });        
    }catch(e){
        console.log(e.message);
        return resp.status(500).json({result:false});
    }
    
});

module.exports = router;