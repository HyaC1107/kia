const express = require("express");
const dotenv = require("dotenv");
const morgan = require("morgan")
const cors = require("cors");
const mongoose = require("mongoose");
const playerRouter = require("./router/player");
const recordRouter = require("./router/record");
const supportRouter = require("./router/support");


dotenv.config();
mongoose.connect(process.env.MONGODB_URI,{dbName:"KIA"})
const app = express();

app.use(cors());
app.use(morgan("[Server] :method :url :status (:response-time ms)"));
app.use(express.urlencoded({extended: true}));
app.use(express.json());

app.use("/tigers/player", playerRouter);
app.use("/tigers/record", recordRouter);
app.use("/tigers/support", supportRouter);


app.listen(8080, ()=>{
    console.log("[server] start.");
});
